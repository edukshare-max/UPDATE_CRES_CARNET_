﻿CRES CARNETS - RELEASE WINDOWS
==============================

Version: 20251011_011859
Plataforma: Windows x64
Tipo: Release

INSTRUCCIONES DE USO:
1. Ejecutar cres_carnets_ibmcloud.exe
2. Asegurar conexion a internet para sincronizacion

CONTENIDO DEL PAQUETE:
- cres_carnets_ibmcloud.exe (Aplicacion principal)
- flutter_windows.dll
- Plugins de Windows
- Datos de la aplicacion

Para soporte tecnico, contactar al equipo de desarrollo.
